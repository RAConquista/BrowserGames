-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2016 at 02:47 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sfgame`
--

-- --------------------------------------------------------

--
-- Table structure for table `copycats`
--

CREATE TABLE `copycats` (
  `ID` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `lvl` smallint(6) NOT NULL DEFAULT '150',
  `class` tinyint(4) NOT NULL,
  `str` mediumint(9) NOT NULL,
  `dex` mediumint(9) NOT NULL,
  `intel` mediumint(9) NOT NULL,
  `wit` mediumint(9) NOT NULL,
  `luck` mediumint(9) NOT NULL DEFAULT '547'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `fortress`
--

CREATE TABLE `fortress` (
  `fortressID` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `stone` int(11) NOT NULL DEFAULT '0',
  `wood` int(11) NOT NULL DEFAULT '0',
  `u1` tinyint(2) NOT NULL DEFAULT '0',
  `u2` tinyint(4) NOT NULL DEFAULT '0',
  `u3` tinyint(4) NOT NULL DEFAULT '0',
  `ul1` tinyint(4) NOT NULL DEFAULT '1',
  `ul2` tinyint(4) DEFAULT '1',
  `ul3` tinyint(4) NOT NULL DEFAULT '1',
  `ut1` tinyint(4) NOT NULL DEFAULT '0',
  `ut2` tinyint(4) NOT NULL DEFAULT '0',
  `ut3` tinyint(4) NOT NULL DEFAULT '0',
  `uttime1` int(11) NOT NULL DEFAULT '0',
  `uttime2` int(11) NOT NULL DEFAULT '0',
  `uttime3` int(11) NOT NULL DEFAULT '0',
  `enemyid` int(11) NOT NULL DEFAULT '0',
  `enemytime` int(11) NOT NULL DEFAULT '0',
  `build_id` tinyint(4) NOT NULL DEFAULT '0',
  `build_start` int(11) NOT NULL DEFAULT '0',
  `build_end` int(11) NOT NULL DEFAULT '0',
  `dig_start` int(11) NOT NULL DEFAULT '0',
  `dig_end` int(11) NOT NULL DEFAULT '0',
  `gather1` int(11) NOT NULL DEFAULT '0',
  `gather2` int(11) NOT NULL DEFAULT '0',
  `gather3` int(11) NOT NULL DEFAULT '0',
  `hok` tinyint(4) NOT NULL DEFAULT '0',
  `b0` tinyint(4) NOT NULL DEFAULT '0',
  `b1` tinyint(4) NOT NULL DEFAULT '0',
  `b2` tinyint(4) NOT NULL DEFAULT '0',
  `b3` tinyint(4) NOT NULL DEFAULT '0',
  `b4` tinyint(4) NOT NULL DEFAULT '0',
  `b5` tinyint(4) NOT NULL DEFAULT '0',
  `b6` tinyint(4) NOT NULL DEFAULT '0',
  `b7` tinyint(4) NOT NULL DEFAULT '0',
  `b8` tinyint(4) NOT NULL DEFAULT '0',
  `b9` tinyint(4) NOT NULL DEFAULT '0',
  `b10` tinyint(4) NOT NULL DEFAULT '0',
  `b11` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `guildchat`
--

CREATE TABLE `guildchat` (
  `ID` int(11) NOT NULL,
  `guildID` int(11) NOT NULL,
  `playerID` int(11) NOT NULL,
  `message` char(255) NOT NULL,
  `time` int(11) NOT NULL,
  `chattime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `guildfightlogs`
--

CREATE TABLE `guildfightlogs` (
  `ID` int(11) NOT NULL,
  `guildAttacker` int(11) NOT NULL,
  `guildDefender` int(11) NOT NULL,
  `log` mediumtext NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `guildfights`
--

CREATE TABLE `guildfights` (
  `ID` int(11) NOT NULL,
  `guildAttacker` int(11) NOT NULL,
  `guildDefender` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `guildinvites`
--

CREATE TABLE `guildinvites` (
  `ID` int(11) NOT NULL,
  `guildID` int(11) NOT NULL,
  `playerID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `guilds`
--

CREATE TABLE `guilds` (
  `ID` int(11) NOT NULL,
  `name` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `base` tinyint(4) NOT NULL DEFAULT '10',
  `treasure` int(11) NOT NULL DEFAULT '0',
  `instructor` int(11) NOT NULL DEFAULT '0',
  `silver` int(11) NOT NULL DEFAULT '1000',
  `mush` int(11) NOT NULL DEFAULT '0',
  `honor` int(11) NOT NULL DEFAULT '100',
  `portal` tinyint(4) NOT NULL DEFAULT '0',
  `portal_hp` bigint(20) NOT NULL DEFAULT '1003472384',
  `dungeon` tinyint(4) NOT NULL DEFAULT '0',
  `attack_init` int(11) NOT NULL DEFAULT '0',
  `event_trigger_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `ID` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `slot` smallint(6) NOT NULL,
  `type` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `dmg_min` int(11) NOT NULL DEFAULT '0',
  `dmg_max` int(11) NOT NULL DEFAULT '0',
  `a1` int(11) NOT NULL DEFAULT '0',
  `a2` int(11) NOT NULL DEFAULT '0',
  `a3` int(11) NOT NULL DEFAULT '0',
  `a4` int(11) NOT NULL DEFAULT '0',
  `a5` int(11) NOT NULL DEFAULT '0',
  `a6` int(11) DEFAULT '0',
  `value_silver` int(11) NOT NULL,
  `value_mush` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `ID` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `reciver` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `topic` char(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `hasRead` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `ID` int(11) NOT NULL,
  `onlineCount` smallint(6) NOT NULL DEFAULT '0',
  `lastUpdate` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `playerfightlogs`
--

CREATE TABLE `playerfightlogs` (
  `ID` int(11) NOT NULL,
  `attacker` int(11) NOT NULL,
  `defender` int(11) NOT NULL,
  `log` mediumtext NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `ID` int(11) NOT NULL,
  `name` char(26) NOT NULL,
  `password` char(40) CHARACTER SET latin1 NOT NULL,
  `lastLoginCount` int(3) NOT NULL DEFAULT '0',
  `face` char(32) CHARACTER SET latin1 NOT NULL,
  `ssid` char(32) CHARACTER SET latin1 NOT NULL,
  `poll` int(11) NOT NULL DEFAULT '0',
  `lvl` smallint(6) NOT NULL DEFAULT '1',
  `exp` bigint(20) NOT NULL DEFAULT '0',
  `quest_dur1` smallint(6) NOT NULL,
  `quest_dur2` smallint(6) NOT NULL,
  `quest_dur3` smallint(6) NOT NULL,
  `quest_exp1` int(11) NOT NULL,
  `quest_exp2` int(11) NOT NULL,
  `quest_exp3` int(11) NOT NULL,
  `quest_silver1` int(11) NOT NULL,
  `quest_silver2` int(11) NOT NULL,
  `quest_silver3` int(11) NOT NULL,
  `str` smallint(6) NOT NULL DEFAULT '10',
  `dex` smallint(6) NOT NULL DEFAULT '10',
  `intel` smallint(6) NOT NULL DEFAULT '10',
  `wit` smallint(6) NOT NULL DEFAULT '10',
  `luck` smallint(6) NOT NULL DEFAULT '10',
  `potion_type1` tinyint(4) NOT NULL DEFAULT '0',
  `potion_type2` tinyint(4) NOT NULL DEFAULT '0',
  `potion_type3` tinyint(4) NOT NULL DEFAULT '0',
  `potion_dur1` int(11) NOT NULL DEFAULT '0',
  `potion_dur2` int(11) NOT NULL DEFAULT '0',
  `potion_dur3` int(11) NOT NULL DEFAULT '0',
  `silver` bigint(20) NOT NULL DEFAULT '100',
  `mush` int(11) NOT NULL DEFAULT '10000000',
  `thirst` smallint(5) NOT NULL DEFAULT '6000',
  `beers` tinyint(4) NOT NULL DEFAULT '0',
  `honor` int(11) NOT NULL DEFAULT '100',
  `race` tinyint(1) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `class` tinyint(1) NOT NULL,
  `mount` tinyint(4) NOT NULL DEFAULT '0',
  `mount_time` int(11) NOT NULL DEFAULT '0',
  `album` smallint(6) NOT NULL DEFAULT '-1',
  `album_data` varchar(1024) CHARACTER SET latin1 NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `status_extra` tinyint(4) NOT NULL DEFAULT '0',
  `status_time` int(11) NOT NULL DEFAULT '0',
  `dungeon_time` int(11) NOT NULL DEFAULT '0',
  `arena_time` int(11) NOT NULL DEFAULT '0',
  `arena_nme1` int(11) NOT NULL DEFAULT '0',
  `arena_nme2` int(11) NOT NULL DEFAULT '0',
  `arena_nme3` int(11) NOT NULL DEFAULT '0',
  `tower` tinyint(4) NOT NULL DEFAULT '0',
  `wcaura` smallint(6) NOT NULL DEFAULT '1',
  `wcexp` smallint(6) NOT NULL DEFAULT '0',
  `wcdate` int(11) NOT NULL DEFAULT '0',
  `portal` tinyint(4) NOT NULL DEFAULT '0',
  `portal_hp` bigint(20) NOT NULL DEFAULT '35938800',
  `portal_time` smallint(6) NOT NULL DEFAULT '0',
  `gportal_time` int(11) NOT NULL DEFAULT '0',
  `guild` int(11) NOT NULL DEFAULT '0',
  `guild_rank` tinyint(4) NOT NULL DEFAULT '3',
  `guild_fight` tinyint(4) NOT NULL DEFAULT '0',
  `event_trigger_count` int(11) NOT NULL DEFAULT '0',
  `d1` tinyint(4) NOT NULL DEFAULT '2',
  `d2` tinyint(4) DEFAULT '2',
  `d3` tinyint(4) NOT NULL DEFAULT '2',
  `d4` tinyint(4) NOT NULL DEFAULT '2',
  `d5` tinyint(4) NOT NULL DEFAULT '2',
  `d6` tinyint(4) NOT NULL DEFAULT '2',
  `d7` tinyint(4) NOT NULL DEFAULT '2',
  `d8` tinyint(4) NOT NULL DEFAULT '2',
  `d9` tinyint(4) NOT NULL DEFAULT '2',
  `d10` tinyint(4) NOT NULL DEFAULT '2',
  `d11` tinyint(4) NOT NULL DEFAULT '2',
  `d12` tinyint(4) NOT NULL DEFAULT '2',
  `d13` tinyint(4) NOT NULL DEFAULT '2',
  `d14` tinyint(4) NOT NULL DEFAULT '2',
  `dd1` tinyint(4) NOT NULL DEFAULT '2',
  `dd2` tinyint(4) NOT NULL DEFAULT '2',
  `dd3` tinyint(4) NOT NULL DEFAULT '2',
  `dd4` tinyint(4) NOT NULL DEFAULT '2',
  `dd5` tinyint(4) NOT NULL DEFAULT '2',
  `dd6` tinyint(4) NOT NULL DEFAULT '2',
  `dd7` tinyint(4) NOT NULL DEFAULT '2',
  `dd8` tinyint(4) NOT NULL DEFAULT '2',
  `dd9` tinyint(4) NOT NULL DEFAULT '2',
  `dd10` tinyint(4) NOT NULL DEFAULT '2',
  `dd11` tinyint(4) NOT NULL DEFAULT '2',
  `dd12` tinyint(4) NOT NULL DEFAULT '2',
  `dd13` tinyint(4) NOT NULL DEFAULT '2',
  `dd14` tinyint(4) NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `copycats`
--
ALTER TABLE `copycats`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `fortress`
--
ALTER TABLE `fortress`
  ADD PRIMARY KEY (`fortressID`),
  ADD KEY `owner` (`owner`),
  ADD KEY `owner_2` (`owner`);

--
-- Indexes for table `guildchat`
--
ALTER TABLE `guildchat`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `guildID` (`guildID`),
  ADD KEY `chattime` (`chattime`);

--
-- Indexes for table `guildfightlogs`
--
ALTER TABLE `guildfightlogs`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `guildAttacker` (`guildAttacker`),
  ADD KEY `guildDefender` (`guildDefender`),
  ADD KEY `time` (`time`);

--
-- Indexes for table `guildfights`
--
ALTER TABLE `guildfights`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `guildAttacker` (`guildAttacker`),
  ADD KEY `guildDefender` (`guildDefender`);

--
-- Indexes for table `guildinvites`
--
ALTER TABLE `guildinvites`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `guildID` (`guildID`);

--
-- Indexes for table `guilds`
--
ALTER TABLE `guilds`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `honor` (`honor`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `reciver` (`reciver`);

--
-- Indexes for table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `playerfightlogs`
--
ALTER TABLE `playerfightlogs`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `time` (`time`),
  ADD KEY `attacker` (`attacker`),
  ADD KEY `defender` (`defender`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ssid` (`ssid`),
  ADD KEY `guild` (`guild`),
  ADD KEY `honor` (`honor`),
  ADD KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `copycats`
--
ALTER TABLE `copycats`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fortress`
--
ALTER TABLE `fortress`
  MODIFY `fortressID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guildchat`
--
ALTER TABLE `guildchat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guildfightlogs`
--
ALTER TABLE `guildfightlogs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guildfights`
--
ALTER TABLE `guildfights`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guildinvites`
--
ALTER TABLE `guildinvites`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guilds`
--
ALTER TABLE `guilds`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `online`
--
ALTER TABLE `online`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `playerfightlogs`
--
ALTER TABLE `playerfightlogs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
