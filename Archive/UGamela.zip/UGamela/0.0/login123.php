<?
/*header('Content-type: text/plain');
echo '<?

	echo "juas, re loco!";
	echo "Hey! que miras?";
	echo "Ops, me salio mal es codigo..."; //w

/*?*>';*/




?><center><table><tr><td></td><td></td><td></td></tr><tr><td></td><td><img src="http://perberos.no-ip.info/gatos/src/1132930349038.jpg"></td><td></td></tr><tr><td></td><td></td><td></td></tr></table></center>