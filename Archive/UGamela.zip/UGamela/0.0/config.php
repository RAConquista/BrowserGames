<?php

if(!defined('INSIDE')){ die("attemp hacking");}
	$dbsettings = Array(
		"server"        => "localhost", // MySQL server name. (Default: localhost)
		"user"          => "root", // MySQL username.
		"pass"          => "", // MySQL password.
		"name"          => "ugamela", // MySQL database name.
		"prefix"        => "ugml_", // Prefix for table names.
		"secretword"    => "ugamela"); // Secret word used when hashing information for cookies.

// Created by Perberos. All rights reversed (C) 2006
?>
