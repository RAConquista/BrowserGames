<?

$info = array(

'title' => "Tecnolog�a i�nica",
'description' => "La tecnolog�a i�nica enfoca un rayo de iones acelerados en un objetivo, lo que puede provocar un gran da�o debido a su naturaleza de electrones cargados de energ�a."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>