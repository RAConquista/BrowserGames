<?

$info = array(

'title' => "Tecnolog�a militar",
'description' => "esta tecnologia incrementa la eficiencia de tus sistemas de armamento. Cada mejor de latecnologia militar a�ade un 10% de potencia a la base de da�o de cualquier arma disponible."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>