<?

$info = array(

'title' => "Laboratorio de investigacion",
'description' => "El Laboratorio de investigacion es necesario para investigar nuevas tecnologias"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>