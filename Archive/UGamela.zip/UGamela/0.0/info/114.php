<?

$info = array(

'title' => "Tecnolog�a de hiperespacio",
'description' => "Incorporando la cuarta y quinta dimensi�n en la tecnolog�a de propulsi�n, se puede disponer de un nuevo tipo de motor; que es m�s eficiente y usa menos combustible que los convencionales."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>