<?

$info = array(

'title' => "Base lunar",
'description' => "Dado que la luna no tiene atm�sfera, se necesita una base lunar para generar espacio habitable. La base lunar no solo provee el ox�geno necesario, tambi�n la gravedad artificial, temperatura y protecci�n necesarias. Cuanto m�s se mejore la base lunar, mayor es el �rea para construir estructuras. Cada nivel de la base lunar proporciona 3 campos lunares , hasta que la luna est� totalmente llena.

Una vez construida, la base lunar no puede ser desmontada."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>