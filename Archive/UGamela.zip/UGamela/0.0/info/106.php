<?

$info = array(

'title' => "Tecnologia de espionaje",
'description' => "Usando esta tecnolog�a, puede obtenerse informaci�n sobre otros planetas, necesaria si se planea atacar."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>