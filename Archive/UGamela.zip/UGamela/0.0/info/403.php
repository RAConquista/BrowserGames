<?

$info = array(

'title' => "L�ser grande",
'description' => "Por medio de un rayo l�ser concentrado, se puede provocar m�s da�o que con las armas bal�sticas normales."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>