<?

$info = array(

'title' => "Plant de energia solar",
'description' => "Para proporcionar la energ�a necesaria para el funcionamiento de los edificios, se requieren enormes plantas de energ�a. Una planta solar es una forma de crear energ�a, puesto que utiliza semiconductores de c�lulas fotovoltaicas, que convierten los fotones en corriente el�ctrica. Cuanto m�s se mejore la planta solar, mayor ser� el area para convertir la luz solar en energ�a y por tanto mayor ser� la generada. Las plantas de energ�a solar son la espina dorsal de cualquier infraestructura planetaria."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>