<?

$info = array(

'title' => "Colonizador",
'description' => "Esta nave proporciona lo necesario para ir a donde ning�n hombre ha llegado antes y colonizar nuevos mundos."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>