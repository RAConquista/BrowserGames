<?

$info = array(

'title' => "Motor de impulso",
'description' => "El sistema del motor de impulso se basa en el principio de la repulsi�n de part�culas. La materia repelida es basura generada por el reactor de fusi�n usado para proporcionar la energ�a necesaria para este tipo de motor de propulsi�n."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>