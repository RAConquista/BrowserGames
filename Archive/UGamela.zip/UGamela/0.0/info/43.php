<?

$info = array(

'title' => "Salto cu�ntico",
'description' => "Los portales del salto cu�ntico son enormes transmisores-receptores capaces de enviar incluso la flota m�s grande instantaneamente a un portal distante en cualquier galaxia. Necesitan la tecnolog�a m�s sofisticada ya que se precisa una cantidad inmensa de energ�a para cumplir con esta tarea."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>