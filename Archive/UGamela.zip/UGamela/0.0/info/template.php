<?

$info = array(

'title' => "titulo",
'description' => "description"

);

// Created by Perberos. All rights reversed (C) 2006
?>