<?

$info = array(

'title' => "Misil interplanetario",
'description' => "Los misiles interplanetarios destruyen los sistemas de defensa del enemigo."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>