<?

$info = array(

'title' => "titulo",
'description' => "description"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>