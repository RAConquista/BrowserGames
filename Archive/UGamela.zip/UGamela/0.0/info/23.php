<?

$info = array(

'title' => "Almacen de cristal",
'description' => "Cuando se tiene una mina que produce mucho cristal,exede la capacidad para procesar el cristal,entonces es necesario tener Almacenes para el cristal no procesado"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>