<?

$info = array(

'title' => "Reciclador",
'description' => "Los recicladores se usan para recolectar escombros flotando en el espacio para reciclarlos en recursos �tiles."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>