<?

$info = array(

'title' => "Hangar",
'description' => "El Hangar es muy necesario para un Imperio en crecimiento, se usa para ensamblar naves y defensa"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>