<?

$info = array(

'title' => "Tecnolog�a de plasma",
'description' => "Las armas de plasma son incluso m�s peligrosas que cualquier otro sistema de armamento conocido, debido a la naturaleza agresiva del plasma."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>