<?

$info = array(

'title' => "Nave grande de carga",
'description' => "La nave grande de carga es una versi�n avanzada de las naves peque�as de carga, permitiendo as� una mayor capacidad de almacenamiento y velocidades m�s altas gracias a un mejor sistema de propulsi�n."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>