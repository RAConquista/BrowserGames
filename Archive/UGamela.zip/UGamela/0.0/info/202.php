<?

$info = array(

'title' => "Nave peque�a de carga",
'description' => "Las naves peque�as de carga son naves muy �giles usadas para transportar recursos desde un planeta a otro."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>