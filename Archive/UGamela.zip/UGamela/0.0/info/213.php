<?

$info = array(

'title' => "Destructor",
'description' => "El destructor es la nave m�s pesada jam�s vista y posee un potencial de ataque sin precedentes."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>