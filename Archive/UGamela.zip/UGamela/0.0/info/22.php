<?

$info = array(

'title' => "Almacen de metal",
'description' => "Cuando se tiene una mina que produce mucho metal,exede la capacidad para procesar el metal,entonces es necesario tener Almacenes para el metal no procesado."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>