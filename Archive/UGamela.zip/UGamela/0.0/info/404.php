<?

$info = array(

'title' => "Ca��n Gauss",
'description' => "Usando una inmensa aceleraci�n electromagn�tica, los ca�ones gauss aceleran proyectiles pesados."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>