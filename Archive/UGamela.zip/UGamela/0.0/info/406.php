<?

$info = array(

'title' => "Ca��n de plasma",
'description' => "Los ca�ones de plasma liberan la energ�a de una peque�a erupci�n solar en una bala de plasma. La energ�a destructiva es incluso superior a la del Destructor."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>