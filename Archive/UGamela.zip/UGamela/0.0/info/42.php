<?

$info = array(

'title' => "Sensor Phalanx",
'description' => "Una cadena de sensores de alta resoluci�n se usa para escanear un enorme espectro de frecuencia. Las unidades de proceso paralelo masivo analizan entonces las se�ales recibidas para detectar incluso la m�s m�nima anomal�a en la frecuencia o fortalecimiento, para detectar maniobras de flotas en imperios distantes. Debido a la complejidad del sistema, cada escaneo necesita una cantidad moderada de deuterio para proporcionar la energ�a necesaria."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>