<?

$info = array(

'title' => "Red de investigaci�n intergal�ctica",
'description' => "Los cient�ficos de tus planetas pueden comunicarse entre ellos a trav�s de esta red."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>