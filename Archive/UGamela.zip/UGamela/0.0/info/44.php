<?

$info = array(

'title' => "Silo",
'description' => "El Silo de misiles,se usa para almacenar y lanzar misiles planetarios"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>