<?

$info = array(

'title' => "Lanzamisiles",
'description' => "El lanzamisiles es un sistema de defensa sencillo, pero barato."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>