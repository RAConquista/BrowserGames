<?

$info = array(

'title' => "C�pula peque�a de protecci�n",
'description' => "La c�pula peque�a de protecci�n cubre el planeta con un delgado campo protector que puede absorber inmensas cantidades de energ�a."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>