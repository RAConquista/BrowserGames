<?

$info = array(

'title' => "Sintetisador de Deuterio",
'description' => " 	El deuterio es agua pesada: los n�cleos de hidrogeno contienen un neutr�n adicional y es muy �til como combustible para las naves por la gran cantidad de energ�a liberada de la reacci�n entre deuterio y tritio (reacci�n DT). El deuterio puede ser encontrado frecuentemente en el mar profundo, debido a su peso molecular, y mejorar el sintetizador de deuterio, permite la recolecci�n de este recurso."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>