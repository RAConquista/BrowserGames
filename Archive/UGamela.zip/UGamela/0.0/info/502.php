<?

$info = array(

'title' => "Misil de intercepci�n",
'description' => "Los misiles de intercepci�n destruyen los misiles interplanetarios."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>