<?

$info = array(

'title' => "Sonda de espionaje",
'description' => "Las sondas de espionaje son peque�os droides no tripulados con un sistema de propulsi�n excepcionalmente r�pido usado para espiar en planetas enemigos."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>