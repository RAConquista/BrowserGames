<?

$info = array(

'title' => "Tecnolog�a de energ�a",
'description' => "Entendiendo la tecnolog�a de diferentes tipos de energ�a, muchas investigaciones nuevas y avanzadas pueden ser adaptadas. La tecnolog�a de energ�a es de gran importancia para un laboratorio de investigaci�n moderno."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>