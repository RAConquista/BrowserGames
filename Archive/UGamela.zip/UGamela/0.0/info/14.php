<?

$info = array(

'title' => "Fabrica de robots",
'description' => "Las fabricas de robots , proporcionan unidades baaratas y de facil construccion, que pueden ser usadas para mejorar o construir cualquier estructura planetaria.Cada nivel de mejora de la fabrica aumenta la tecnologia como tambien el numero de unidades roboticas que ayudan en la construccion."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>