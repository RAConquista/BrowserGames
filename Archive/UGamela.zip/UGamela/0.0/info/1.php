<?

$info = array(

'title' => "Mina de metal",
'description' => " 	Las minas de metal proveen los recursos b�sicos de un imperio emergente, y permiten la construcci�n de edificios y naves. El metal es el material m�s barato disponible, y requiere poca energ�a para su recolecci�n, pero se usa mucho m�s frecuentemente que el resto de recursos. Se encuentra en profundidad, debajo de la superficie, lo que conduce a minas cada vez m�s profundas que necesitan m�s energ�a para funcionar."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>