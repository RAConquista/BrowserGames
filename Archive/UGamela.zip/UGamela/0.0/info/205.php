<?

$info = array(

'title' => "Cazador pesado",
'description' => "El cazador pesado es la evoluci�n logica del ligero, ofreciendo escudos reforzados y una mayor potencia de ataque."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>