<?

$info = array(

'title' => "Motor de combusti�n",
'description' => "Ejecutar investigaciones en esta tecnolog�a proporciona motores de combusti�n siempre m�s rapido, aunque cada nivel aumenta solamente la velocidad en un 10% de la velocidad base de una nave dada."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>