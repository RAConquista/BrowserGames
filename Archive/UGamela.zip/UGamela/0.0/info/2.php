<?

$info = array(

'title' => "Mina de Cristal",
'description' => "Los cristales son el recurso principal usado para construir circuitos electr�nicos y ciertas aleaciones. Comparado con el proceso de producci�n del metal, el proceso de conversi�n de estructuras cristalinas en cristales industriales, requiere aproximadamente el doble de energ�a; por lo que los cristales son m�s caros al comerciar. Cada nave y edificio necesita una cierta cantidad de cristales, pero los apropiados son muy escasos y se encuentran en grandes profundidades. Las minas necesarias para recolectarlos, por ello, se vuelven m�s caras al alcanzar mayores profundidades, pero, ciertamente, proveen de m�s cristales que minas menos profundas."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>