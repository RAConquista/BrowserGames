<?

$info = array(

'title' => "Tecnologia de defensa",
'description' => "La tecnolog�a de defensa se usa para generar un escudo de part�culas protectoras alrededor de tus estructuras.
Cada nivel de esta tecnolog�a aumenta el escudo efectivo en un 10% (basado en el nivel de una estructura dada)."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>