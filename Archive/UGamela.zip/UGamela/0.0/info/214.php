<?

$info = array(

'title' => "Estrella de la muerte",
'description' => "La fuerza de la destrucci�n de la estrella de la muerte es inancanzable"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>