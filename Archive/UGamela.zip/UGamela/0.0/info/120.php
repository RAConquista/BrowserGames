<?

$info = array(

'title' => "Tecnolog�a l�ser",
'description' => "La tecnolog�a l�ser es un importante conocimiento; conduce a la luz monocrom�tica firmemente enfocada sobre un objetivo. El da�o puede ser ligero o moderado dependiendo de la potencia del rayo..."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>