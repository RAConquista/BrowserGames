<?

$info = array(

'title' => "Ca��n i�nico",
'description' => "Los ca�ones i�nicos disparan rayos de iones altamente energ�ticos contra su objetivo, desestabilizando los escudos y destruyendo los componentes electr�nicos."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>