<?

$info = array(

'title' => "Nave de batalla",
'description' => "Las naves de batalla son la espina dorsal de cualquier flota militar. Blindaje pesado, potentes sistemas de armamento y una alta velocidad de viaje, as� como una gran capacidad de carga hace de esta nave un duro rival contra el que luchar."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>