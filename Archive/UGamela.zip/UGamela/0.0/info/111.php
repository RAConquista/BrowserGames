<?

$info = array(

'title' => "Tecnolog�a de blindaje",
'description' => "Las aleaciones altamente sofisticadas ayudan a incrementar el blindaje de una nave a�adiendo el 10% de su fuerza en cada nivel a la fuerza base."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>