<?

$info = array(

'title' => "Propulsor hiperespacial",
'description' => "Los motores de hiperespacio permiten entrar al mismo a trav�s de una ventana hiperespacial para reducir dr�sticamente el tiempo de viaje. El hiperespacio es un espacio alternativo con m�s de 3 dimensiones."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>