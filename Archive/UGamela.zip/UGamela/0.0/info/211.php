<?

$info = array(

'title' => "Bombardero",
'description' => "El Bombardero es una nave de prop�sito especial, desarrollado para atravesar las defensas planetarias m�s pesadas."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>