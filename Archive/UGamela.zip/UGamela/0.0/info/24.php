<?

$info = array(

'title' => "Almacen de deuterio",
'description' => "Cuando se produce demaciado deuterio,exede la capacidad de lugar para almacenarce,entonces es necesario tener contenedores gigantes para deuterio"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>