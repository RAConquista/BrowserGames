<?

$info = array(

'title' => "Crucero",
'description' => "Los cruceros de combate tienen un escudo casi tres veces m�s fuerte que el de los cazadores pesados y m�s del doble de potencia de ataque. Su velocidad de desplazamiento est� tambi�n entre las m�s r�pidas jam�s vista."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>