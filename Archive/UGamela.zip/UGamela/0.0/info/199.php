<?

$info = array(

'title' => "Tecnolog�a de gravit�n",
'description' => "A trav�s del disparo de part�culas concentradas de gravit�n se genera un campo gravitacional artificial con suficiente potencia y poder de atracci�n para destruir no solo naves, sino lunas enteras."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>