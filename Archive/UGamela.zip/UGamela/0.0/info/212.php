<?

$info = array(

'title' => "Sat�lite solar",
'description' => "Los sat�lites solares son simples sat�lites en �rbita equipados con c�lulas fotovoltaicas y transmisores para llevar la energ�a al planeta. Se transmite por este medio a la tierra usando un rayo l�ser especial."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>