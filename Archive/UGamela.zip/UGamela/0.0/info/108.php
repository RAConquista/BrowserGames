<?

$info = array(

'title' => "Tecnolog�a de computaci�n",
'description' => "Cuanto mas elevado sea el nivel de tecnologia de computacion,mas flotas podras controlar simultaneamente,Cada nivel adicional ed esta tecnologia,aumenta el numero de flotas que puedes controlar en 1"

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>