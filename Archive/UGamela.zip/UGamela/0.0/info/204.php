<?

$info = array(

'title' => "Cazador ligero",
'description' => "El cazador ligero es una nave maniobrable que puedes encontrar en casi cualquier planeta. El coste no es particularmente alto, pero asimismo el escudo y la capacidad de carga son muy bajas."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>