<?

$info = array(

'title' => "C�pula grande de protecci�n",
'description' => "La c�pula grande de protecci�n proviene de una tecnolog�a de defensa mejorada que absorbe incluso m�s energ�a antes de colapsarse."

);

// Created by Gameforge GmbH . All rights reversed (C) 2006
?>