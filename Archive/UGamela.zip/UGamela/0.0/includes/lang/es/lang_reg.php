<?php


if(!defined('INSIDE')){ die("attemp hacking");}

// message.php
$lang['Indefinide'] = 'Indefinido';
$lang['Male'] = 'Mujer';
$lang['Female'] = 'Hombre';
$lang['Multiverse'] = 'Multiverse';
$lang['E-Mail'] = 'Direcci�n de correo electr�nico (por ej. astroboy@mail.com)';
$lang['MainPlanet'] = 'Nombre del planeta principal (no utilices signos especiales)';
$lang['GameName'] = 'Nombre en el juego';
$lang['Sex'] = 'Sexo';
$lang['accept'] = 'Con mi inscripci�n acepto las <a href="help.php?conditions">condiciones y t�rminos generales de uso</a>';

// Created by Perberos. All rights reversed (C) 2006 
?>
