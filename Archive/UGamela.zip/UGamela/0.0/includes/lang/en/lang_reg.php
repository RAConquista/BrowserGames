<?php


if(!defined('INSIDE')){ die("attemp hacking");}

// message.php
$lang['Indefinide'] = 'Indefinide';
$lang['Male'] = 'Male';
$lang['Female'] = 'Female';
$lang['Multiverse'] = 'Multiverse';
$lang['E-Mail'] = 'E-Mail Address (by example astroboy@mail.com)';
$lang['MainPlanet'] = 'Main Planet Name';
$lang['GameName'] = 'Ingame Nick';
$lang['Sex'] = 'Sex';
$lang['accept'] = 'I accept the <a href="help.php?conditions">terms and conditions</a>';
$lang['signup'] = 'Sign Up';
// Created by Perberos. All rights reversed (C) 2006 
?>
