Condiciones de uso:

  Este programa no tiene la intencion de reemplazar el juego original. Ni la intencion de lucrar con el mismo.
El autor no se hace responsable de su difamacion. O cualquier adulterio a la reputacion del juego original.

  El juego antes mensionado. Solo se utilizara como referencia. La cual no posee ningun vinculo legal.

  El juego no posee auspiciantes ni autoridades legales. Lo cual no quiere decir que sea ilegal. El juego no
se tiene ninguna ley vigente.

  La idea principal del juego. Es demostrar que si uno se lo propone. Puede hacerlo. Aunque sea solo. :)

Agradecimientos:

  Un agradecimiento especial a edmundo. Que fue la persona que me dio hosting para el proyecto.
  A prody por el "perberos.com.ar". a Victor Pokusov por el hosting. :D
  A terra por ... ser rosarino xD. Amigazo! un abrazo!
  Y a todas esas personas que me ayudan a no estresarme D':<

Atte. Perberos