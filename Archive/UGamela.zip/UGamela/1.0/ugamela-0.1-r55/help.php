<pre>Condiciones de uso:

  Este programa no tiene la intencion de reemplazar el juego original. Ni la intencion de lucrar con el mismo.
El autor no se hace responsable de su difamacion. O cualquier adulterio a la reputacion del juego original.

  El juego antes mensionado. Solo se utilizara como referencia. La cual no posee ningun vinculo legal.

  El juego no posee auspiciantes ni autoridades legales. Lo cual no quiere decir que sea ilegal. El juego no
se tiene ninguna ley vigente.

  La idea principal del juego. Es demostrar que si uno se lo propone. Puede hacerlo. Aunque sea solo. :)
</pre>