Use some like a server http (WAMP) or (LAMP)

Execute "gameurl"/install/install.php
Example: http://localhost/ugamela/install/install.php

Follow the spanish instruccions xD

PD: There is not admin account possible as yet. Sorry