<?php  //db.php


if ( !defined('INSIDE') )
{
	die("Hacking attempt");
}


include($ugamela_root_path . 'db/mysql.'.$phpEx);

?>