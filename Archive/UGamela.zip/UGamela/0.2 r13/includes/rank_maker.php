<?php // rank_maker.php ::  Permite actualizar el ranking. v0.0

/*
  Version MiiChoo, Heavy Update.
*/

function rank_maker(){

	//obtenemos todas las variables
	$planets = doquery('SELECT * FROM {{table}}','planets');
	$users = doquery('SELECT * FROM {{table}}','users');
	
	//as




	//get_building_price










}

// Created by MiiChoo. All rights reversed (C) 2007
?>
